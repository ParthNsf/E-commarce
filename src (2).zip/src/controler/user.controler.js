const Users = require("../model/users.model");
const bcrypt = require('bcrypt');

// const getuser = async (req,res) => {

//     try {
//         const aggregatedData = await user.aggregate([
//           // Your aggregation pipeline stages go here
//           // Example:
//           { $group: { _id: '$user', totalProducts: { $sum: 1 } } }
//         ]);
    
//         res.json(aggregatedData);
//       } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'Internal server error' });
//       }
    


//     // try {
//     //     console.log(req.params.user_id);
//     //     const user = await user.findById(req.params.user_id);
//     //     console.log(user);

//     //     if (!user) {
//     //         res.status(404).json({
//     //             success: false,
//     //             message: 'user data not found.'
//     //         })
//     //     }

//     //     res.status(200).json({
//     //         success: false,
//     //         message: 'user data fetched.',
//     //         data: user
//     //     })
//     // } catch (error) {
//     //     res.status(500).json({
//     //         success: false,
//     //         message: 'Internal server error'+ error.message
//     //     })
//     // }
// }

const adduser = async (req,res) => {
    try {

        const { email, password } = req.body

        const bcryptpassword = bcrypt.hash(password, 10)

        console.log(req.body);
        const user = await Users.create({...req.body, password: bcryptpassword});


        console.log(user);

        if (user) {
            res.status(409).json({
                success: false,
                message: 'user can not create.'
            })
        }
        
        if (!bcryptpassword) {
            res.status(500).json({
                success: false,
                message: 'password not bicrpt serverr error.'
            })
        }

        res.status(201).json({
            success: false,
            message: 'user data created.',
            data: user.select("-password")
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Internal server error'+ error.message
        })
    }
}

// const updateuser = async (req,res) => {
//     try {
//         console.log(req.params.user_id);
//         const user = await user.findByIdAndUpdate(req.params.user_id,req.body,{new: true, runValidators: true})


//         if (!user) {
//             res.status(400).json({
//                 success: false,
//                 message: 'user data not found.'
//             })
//         }

//         res.status(200).json({
//             success: false,
//             message: 'user Updated Successfully.',
//             data: user
//         })
//     } catch (error) {
//         res.status(500).json({
//             success: false,
//             message: 'Internal server error'+ error.message
//         })
//     }
// }

// const deleteuser = async (req,res) => {
//     try {
//         console.log(req.params.user_id);
//         const user = await user.findById(req.params.user_id);

//         if (!user) {
//             res.status(404).json({
//                 success: false,
//                 message: 'user data not found.'
//             })
//         }

//         const data = await user.findByIdAndDelete(req.params.user_id)

//         res.status(200).json({
//             success: false,
//             message: 'user Deleted Successfully.',
//             data: data
//         })
//     } catch (error) {
//         res.status(500).json({
//             success: false,
//             message: 'Internal server error'+ error.message
//         })
//     }
// }



module.exports = {
    // listuser,
    adduser,
    // updateuser,
    // deleteuser,
    // getuser,
    // countsubuser
}


