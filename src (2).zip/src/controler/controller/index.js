module.exports.categoriesControler = require("./categories.controler")

module.exports.subcategoriesControler = require("./subcategrories.controler")

module.exports.productsControler = require("./products.controler");