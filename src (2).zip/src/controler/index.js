module.exports.categoriesControler = require("./categories.controler")

module.exports.subcategoriesControler = require("./subcategrories.controler")

module.exports.productsControler = require("./products.controler")

module.exports.varientsControler = require("./variant.controler");

module.exports.salsepersonControler = require("./salespeople.controler");

module.exports.userControler = require("./user.controler");
